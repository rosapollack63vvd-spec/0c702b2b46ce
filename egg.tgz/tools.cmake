# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(svdrandomized src/svdrandomized.cpp)
set_property(TARGET svdrandomized PROPERTY CXX_STANDARD 11)
target_link_libraries(svdrandomized lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(hashAgg src/hashAgg.cpp)
set_property(TARGET hashAgg PROPERTY CXX_STANDARD 11)
target_link_libraries(hashAgg lionss pthread)

add_executable(joinReorder src/joinReorder.cpp)
set_property(TARGET joinReorder PROPERTY CXX_STANDARD 11)
target_link_libraries(joinReorder lionss pthread)

add_executable(mp3_vbr src/mp3_vbr.cpp)
set_property(TARGET mp3_vbr PROPERTY CXX_STANDARD 11)
target_link_libraries(mp3_vbr lionss pthread)

add_executable(borg_compact src/borg_compact.cpp)
set_property(TARGET borg_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(borg_compact lionss pthread)

add_executable(serdetangent src/serdetangent.cpp)
set_property(TARGET serdetangent PROPERTY CXX_STANDARD 11)
target_link_libraries(serdetangent lionss pthread)

add_executable(harrier src/harrier.cpp)
set_property(TARGET harrier PROPERTY CXX_STANDARD 11)
target_link_libraries(harrier lionss pthread)

add_executable(sparrowhawk src/sparrowhawk.cpp)
set_property(TARGET sparrowhawk PROPERTY CXX_STANDARD 11)
target_link_libraries(sparrowhawk lionss pthread)

add_executable(kvcache_evict src/kvcache_evict.cpp)
set_property(TARGET kvcache_evict PROPERTY CXX_STANDARD 11)
target_link_libraries(kvcache_evict lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(penaltyauglag src/penaltyauglag.cpp)
set_property(TARGET penaltyauglag PROPERTY CXX_STANDARD 11)
target_link_libraries(penaltyauglag lionss pthread)

add_executable(reedmace src/reedmace.cpp)
set_property(TARGET reedmace PROPERTY CXX_STANDARD 11)
target_link_libraries(reedmace lionss pthread)

add_executable(telemetry-frame src/telemetry-frame.cpp)
set_property(TARGET telemetry-frame PROPERTY CXX_STANDARD 11)
target_link_libraries(telemetry-frame lionss pthread)

add_executable(opcua_subscribe src/opcua_subscribe.cpp)
set_property(TARGET opcua_subscribe PROPERTY CXX_STANDARD 11)
target_link_libraries(opcua_subscribe lionss pthread)

add_executable(ambisonicb src/ambisonicb.cpp)
set_property(TARGET ambisonicb PROPERTY CXX_STANDARD 11)
target_link_libraries(ambisonicb lionss pthread)

add_executable(lp_dualsimplex src/lp_dualsimplex.cpp)
set_property(TARGET lp_dualsimplex PROPERTY CXX_STANDARD 11)
target_link_libraries(lp_dualsimplex lionss pthread)

add_executable(TurnRelay src/TurnRelay.cpp)
set_property(TARGET TurnRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(TurnRelay lionss pthread)

add_executable(ekf_predict src/ekf_predict.cpp)
set_property(TARGET ekf_predict PROPERTY CXX_STANDARD 11)
target_link_libraries(ekf_predict lionss pthread)

add_executable(recordReplay src/recordReplay.cpp)
set_property(TARGET recordReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(recordReplay lionss pthread)

add_executable(cmaessigma src/cmaessigma.cpp)
set_property(TARGET cmaessigma PROPERTY CXX_STANDARD 11)
target_link_libraries(cmaessigma lionss pthread)

add_executable(gffMerge src/gffMerge.cpp)
set_property(TARGET gffMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(gffMerge lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(ssaDestruct src/ssaDestruct.cpp)
set_property(TARGET ssaDestruct PROPERTY CXX_STANDARD 11)
target_link_libraries(ssaDestruct lionss pthread)

add_executable(dns-doh src/dns-doh.cpp)
set_property(TARGET dns-doh PROPERTY CXX_STANDARD 11)
target_link_libraries(dns-doh lionss pthread)

add_executable(spill-tempfile src/spill-tempfile.cpp)
set_property(TARGET spill-tempfile PROPERTY CXX_STANDARD 11)
target_link_libraries(spill-tempfile lionss pthread)

add_executable(flaxen src/flaxen.cpp)
set_property(TARGET flaxen PROPERTY CXX_STANDARD 11)
target_link_libraries(flaxen lionss pthread)

add_executable(grafanaPanel src/grafanaPanel.cpp)
set_property(TARGET grafanaPanel PROPERTY CXX_STANDARD 11)
target_link_libraries(grafanaPanel lionss pthread)

