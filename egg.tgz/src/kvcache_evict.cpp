// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Evict KV entries");
  std::fflush(stdout);
  return lionss_run_workload("kvcache_evict");
}
