// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Decode B-format"); }
int main(){
  announce();
  return lionss_run_workload("ambisonicb");
}
