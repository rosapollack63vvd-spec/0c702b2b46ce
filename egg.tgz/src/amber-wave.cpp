// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Synthesize amber wave\n", stdout);
  return lionss_run_workload("amber-wave");
}
