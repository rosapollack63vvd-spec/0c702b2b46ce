// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compact repository\n", stdout);
  return lionss_run_workload("borg_compact");
}
