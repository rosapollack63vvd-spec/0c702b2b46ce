// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Quarter harrier field"); }
int main(){
  announce();
  return lionss_run_workload("harrier");
}
